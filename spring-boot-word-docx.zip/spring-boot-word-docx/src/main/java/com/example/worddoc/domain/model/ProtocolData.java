package com.example.worddoc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProtocolData {

    private String title;
    private String content;
    private TableData tableData;
    private List<PreSetImage> images;
}
