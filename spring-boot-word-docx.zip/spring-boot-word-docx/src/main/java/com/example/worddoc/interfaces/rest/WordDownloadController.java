package com.example.worddoc.interfaces.rest;

import com.example.worddoc.application.ProtocolExportService;
import com.example.worddoc.application.SowExportService;
import com.example.worddoc.application.WordDocApplicationService;
import com.example.worddoc.application.dto.DocumentResult;
import com.example.worddoc.application.dto.ExportProtocolCommand;
import com.example.worddoc.application.dto.ExportSowCommand;
import com.example.worddoc.application.dto.GenerateDocumentCommand;
import com.example.worddoc.domain.model.TableData;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
public class WordDownloadController {

    private final WordDocApplicationService wordDocApplicationService;
    private final SowExportService sowExportService;
    private final ProtocolExportService protocolExportService;

    public WordDownloadController(WordDocApplicationService wordDocApplicationService,
                                  SowExportService sowExportService,
                                  ProtocolExportService protocolExportService) {
        this.wordDocApplicationService = wordDocApplicationService;
        this.sowExportService = sowExportService;
        this.protocolExportService = protocolExportService;
    }

    @GetMapping("/download")
    public ResponseEntity<Resource> download(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String bodyText) {

        GenerateDocumentCommand command = new GenerateDocumentCommand(title, bodyText);
        DocumentResult result = wordDocApplicationService.generate(command);

        ByteArrayResource resource = new ByteArrayResource(result.getContent());
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=document.docx")
                .body(resource);
    }

    @PostMapping("/api/sow/export")
    public ResponseEntity<Resource> exportSow(@RequestBody Map<String, Object> request) {
        String title = (String) request.getOrDefault("title", "");
        String description = (String) request.getOrDefault("description", "");
        String date = (String) request.getOrDefault("date", "");

        @SuppressWarnings("unchecked")
        List<List<String>> rows = (List<List<String>>) request.getOrDefault("rows", Collections.emptyList());
        @SuppressWarnings("unchecked")
        List<String> headers = (List<String>) request.getOrDefault("headers", Collections.emptyList());
        TableData tableData = new TableData(headers, rows);

        ExportSowCommand command = new ExportSowCommand(title, description, date, tableData);
        DocumentResult result = sowExportService.exportSow(command);

        return buildResponse(result, "sow.docx");
    }

    @PostMapping("/api/protocol/export")
    public ResponseEntity<Resource> exportProtocol(@RequestBody Map<String, Object> request) {
        String title = (String) request.getOrDefault("title", "");
        String content = (String) request.getOrDefault("content", "");

        @SuppressWarnings("unchecked")
        List<List<String>> rows = (List<List<String>>) request.getOrDefault("rows", Collections.emptyList());
        @SuppressWarnings("unchecked")
        List<String> headers = (List<String>) request.getOrDefault("headers", Collections.emptyList());
        TableData tableData = new TableData(headers, rows);

        ExportProtocolCommand command = new ExportProtocolCommand(title, content, tableData);
        DocumentResult result = protocolExportService.exportProtocol(command);

        return buildResponse(result, "protocol.docx");
    }

    private ResponseEntity<Resource> buildResponse(DocumentResult result, String filename) {
        ByteArrayResource resource = new ByteArrayResource(result.getContent());
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=" + filename)
                .body(resource);
    }
}
