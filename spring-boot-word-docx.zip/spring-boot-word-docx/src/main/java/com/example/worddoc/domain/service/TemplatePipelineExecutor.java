package com.example.worddoc.domain.service;

import java.util.List;
import java.util.Map;

public interface TemplatePipelineExecutor {

    String execute(List<PipelineStep> steps, Map<String, Object> initialModel);

    final class PipelineStep {
        private final String templateName;
        private final String outputVariableName;

        public PipelineStep(String templateName, String outputVariableName) {
            this.templateName = templateName;
            this.outputVariableName = outputVariableName;
        }

        public String getTemplateName() {
            return templateName;
        }

        public String getOutputVariableName() {
            return outputVariableName;
        }
    }
}
