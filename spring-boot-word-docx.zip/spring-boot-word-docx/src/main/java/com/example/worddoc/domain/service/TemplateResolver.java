package com.example.worddoc.domain.service;

public interface TemplateResolver {

    String resolve(String documentType, String templateName);
}
