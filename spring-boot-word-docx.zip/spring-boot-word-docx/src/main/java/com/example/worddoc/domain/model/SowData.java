package com.example.worddoc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SowData {

    private String title;
    private String description;
    private String date;
    private TableData tableData;
    private List<PreSetImage> images;
}
