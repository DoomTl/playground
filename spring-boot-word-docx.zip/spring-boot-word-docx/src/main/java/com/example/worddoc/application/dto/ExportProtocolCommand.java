package com.example.worddoc.application.dto;

import com.example.worddoc.domain.model.PreSetImage;
import com.example.worddoc.domain.model.ProtocolData;
import com.example.worddoc.domain.model.TableData;
import lombok.Value;

import java.util.List;

@Value
public class ExportProtocolCommand {

    String title;
    String content;
    TableData tableData;

    public ProtocolData toDomain(List<PreSetImage> images) {
        return new ProtocolData(title, content, tableData, images);
    }
}
