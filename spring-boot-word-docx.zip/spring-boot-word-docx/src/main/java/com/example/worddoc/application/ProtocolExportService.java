package com.example.worddoc.application;

import com.example.worddoc.application.dto.DocumentResult;
import com.example.worddoc.application.dto.ExportProtocolCommand;
import com.example.worddoc.domain.model.PreSetImage;
import com.example.worddoc.domain.model.ProtocolData;
import com.example.worddoc.domain.service.ArchiveEditor;
import com.example.worddoc.domain.service.TemplateRenderer;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProtocolExportService {

    private final TemplateRenderer templateRenderer;
    private final ArchiveEditor archiveEditor;

    public ProtocolExportService(TemplateRenderer templateRenderer,
                                  ArchiveEditor archiveEditor) {
        this.templateRenderer = templateRenderer;
        this.archiveEditor = archiveEditor;
    }

    public DocumentResult exportProtocol(ExportProtocolCommand command) {
        ProtocolData data = command.toDomain(loadPreSetImages());

        String tableXml = templateRenderer.renderTemplate("table.xml.ftl", data.getTableData());

        String intermediateXml = renderIntermediate(data, tableXml);
        String finalDocXml = renderDocument(data, intermediateXml);

        byte[] templateDocx = loadTemplateDocx("protocol/template.docx");
        templateDocx = archiveEditor.replace(
                templateDocx,
                "word/document.xml",
                finalDocXml.getBytes(StandardCharsets.UTF_8));

        String relsXml = renderRels(data.getImages());
        if (relsXml != null) {
            templateDocx = archiveEditor.replace(
                    templateDocx,
                    "word/_rels/document.xml.rels",
                    relsXml.getBytes(StandardCharsets.UTF_8));
        }

        if (data.getImages() != null) {
            for (PreSetImage img : data.getImages()) {
                templateDocx = archiveEditor.add(
                        templateDocx,
                        "word/media/" + img.getFileName(),
                        img.getData());
            }
        }

        return new DocumentResult(templateDocx);
    }

    private String renderIntermediate(ProtocolData data, String tableXml) {
        Map<String, Object> model = new HashMap<>();
        model.put("title", data.getTitle());
        model.put("description", data.getContent());
        model.put("tableXml", tableXml);
        return templateRenderer.renderTemplate("sow/sow.xml.ftl", model);
    }

    private String renderDocument(ProtocolData data, String intermediateXml) {
        Map<String, Object> model = new HashMap<>();
        model.put("sowXml", intermediateXml);
        return templateRenderer.renderTemplate("protocol/document.xml.ftl", model);
    }

    private String renderRels(List<PreSetImage> images) {
        if (images == null || images.isEmpty()) {
            return null;
        }
        Map<String, Object> model = new HashMap<>();
        model.put("images", images);
        return templateRenderer.renderTemplate("protocol/document.rels.xml.ftl", model);
    }

    private List<PreSetImage> loadPreSetImages() {
        List<PreSetImage> images = new ArrayList<>();
        String[] imageNames = {"image1.png"};
        for (String name : imageNames) {
            try (InputStream is = getClass().getClassLoader()
                    .getResourceAsStream("images/" + name)) {
                if (is != null) {
                    images.add(new PreSetImage(name, readAllBytes(is), 914400L, 914400L));
                }
            } catch (IOException ignored) {
            }
        }
        return images;
    }

    private byte[] loadTemplateDocx(String path) {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(path)) {
            if (is == null) {
                throw new IOException("Template not found: " + path);
            }
            return readAllBytes(is);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load template: " + path, e);
        }
    }

    private byte[] readAllBytes(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int len;
        while ((len = is.read(buf)) != -1) {
            bos.write(buf, 0, len);
        }
        return bos.toByteArray();
    }
}
