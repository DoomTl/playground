package com.example.worddoc.application.dto;

import com.example.worddoc.domain.model.PreSetImage;
import com.example.worddoc.domain.model.SowData;
import com.example.worddoc.domain.model.TableData;
import lombok.Value;

import java.util.List;

@Value
public class ExportSowCommand {

    String title;
    String description;
    String date;
    TableData tableData;

    public SowData toDomain(List<PreSetImage> images) {
        return new SowData(title, description, date, tableData, images);
    }
}
