package com.example.worddoc.infrastructure.template;

import com.example.worddoc.domain.service.TemplatePipelineExecutor;
import com.example.worddoc.domain.service.TemplateRenderer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FreeMarkerPipelineExecutor implements TemplatePipelineExecutor {

    private final TemplateRenderer templateRenderer;

    public FreeMarkerPipelineExecutor(TemplateRenderer templateRenderer) {
        this.templateRenderer = templateRenderer;
    }

    @Override
    public String execute(List<PipelineStep> steps, Map<String, Object> initialModel) {
        Map<String, Object> context = new HashMap<>(initialModel);
        String output = null;

        for (PipelineStep step : steps) {
            if (output != null && step.getOutputVariableName() != null) {
                context.put(step.getOutputVariableName(), output);
            }
            output = templateRenderer.renderTemplate(step.getTemplateName(), context);
        }

        return output;
    }
}
