package com.example.worddoc.infrastructure.template;

import com.example.worddoc.domain.service.TemplateResolver;

public class DocumentTypeTemplateResolver implements TemplateResolver {

    @Override
    public String resolve(String documentType, String templateName) {
        if (documentType == null || documentType.isEmpty()) {
            return templateName;
        }
        return documentType + "/" + templateName;
    }
}
