package com.example.worddoc.application;

import com.example.worddoc.application.dto.DocumentResult;
import com.example.worddoc.application.dto.ExportSowCommand;
import com.example.worddoc.domain.model.PreSetImage;
import com.example.worddoc.domain.model.SowData;
import com.example.worddoc.domain.model.TableData;
import com.example.worddoc.domain.service.ArchiveEditor;
import com.example.worddoc.domain.service.TemplateRenderer;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SowExportService {

    private final TemplateRenderer templateRenderer;
    private final ArchiveEditor archiveEditor;

    public SowExportService(TemplateRenderer templateRenderer,
                            ArchiveEditor archiveEditor) {
        this.templateRenderer = templateRenderer;
        this.archiveEditor = archiveEditor;
    }

    public DocumentResult exportSow(ExportSowCommand command) {
        SowData data = command.toDomain(loadPreSetImages());

        String tableXml = templateRenderer.renderTemplate("table.xml.ftl", data.getTableData());

        String sowBodyXml = renderSowBody(data, tableXml);
        String finalDocXml = renderSowDoc(data, sowBodyXml);

        byte[] templateDocx = loadTemplateDocx("sow/template.docx");
        templateDocx = archiveEditor.replace(
                templateDocx,
                "word/document.xml",
                finalDocXml.getBytes(StandardCharsets.UTF_8));

        String relsXml = renderRels(data.getImages());
        if (relsXml != null) {
            templateDocx = archiveEditor.replace(
                    templateDocx,
                    "word/_rels/document.xml.rels",
                    relsXml.getBytes(StandardCharsets.UTF_8));
        }

        if (data.getImages() != null) {
            for (PreSetImage img : data.getImages()) {
                templateDocx = archiveEditor.add(
                        templateDocx,
                        "word/media/" + img.getFileName(),
                        img.getData());
            }
        }

        return new DocumentResult(templateDocx);
    }

    private String renderSowBody(SowData data, String tableXml) {
        Map<String, Object> model = new HashMap<>();
        model.put("title", data.getTitle());
        model.put("description", data.getDescription());
        model.put("date", data.getDate());
        model.put("tableXml", tableXml);
        return templateRenderer.renderTemplate("sow/sow.xml.ftl", model);
    }

    private String renderSowDoc(SowData data, String sowBodyXml) {
        Map<String, Object> model = new HashMap<>();
        model.put("sowXml", sowBodyXml);
        return templateRenderer.renderTemplate("sow/sowdoc.xml.ftl", model);
    }

    private String renderRels(List<PreSetImage> images) {
        if (images == null || images.isEmpty()) {
            return null;
        }
        Map<String, Object> model = new HashMap<>();
        model.put("images", images);
        return templateRenderer.renderTemplate("sow/sow.rels.xml.ftl", model);
    }

    private List<PreSetImage> loadPreSetImages() {
        List<PreSetImage> images = new ArrayList<>();
        String[] imageNames = {"image1.png"};
        for (String name : imageNames) {
            try (InputStream is = getClass().getClassLoader()
                    .getResourceAsStream("images/" + name)) {
                if (is != null) {
                    images.add(new PreSetImage(name, readAllBytes(is), 914400L, 914400L));
                }
            } catch (IOException ignored) {
            }
        }
        return images;
    }

    private byte[] loadTemplateDocx(String path) {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(path)) {
            if (is == null) {
                throw new IOException("Template not found: " + path);
            }
            return readAllBytes(is);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load template: " + path, e);
        }
    }

    private byte[] readAllBytes(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int len;
        while ((len = is.read(buf)) != -1) {
            bos.write(buf, 0, len);
        }
        return bos.toByteArray();
    }
}
