		<w:tbl>
			<w:tblPr>
				<w:tblStyle w:val="af0"/>
				<w:tblW w:w="0" w:type="auto"/>
				<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>
			</w:tblPr>
			<w:tblGrid>
			<#list headers as header>
				<w:gridCol w:w="2074"/>
			</#list>
			</w:tblGrid>
			<#if headers?has_content>
			<w:tr w:rsidR="00B7639C" w14:paraId="3AA42EB4" w14:textId="77777777" w:rsidTr="00B7639C">
				<#list headers as header>
				<w:tc>
					<w:tcPr>
						<w:tcW w:w="2074" w:type="dxa"/>
						<w:shd w:val="clear" w:color="auto" w:fill="D9E2F3"/>
					</w:tcPr>
					<w:p w14:paraId="2C7D13A1" w14:textId="3C1838E7" w:rsidR="00B7639C" w:rsidRDefault="00B7639C" w:rsidP="00B7639C">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:hint="eastAsia"/>
								<w:b/>
							</w:rPr>
						</w:pPr>
						<w:r>
							<w:rPr>
								<w:rFonts w:hint="eastAsia"/>
								<w:b/>
							</w:rPr>
							<w:t>${header}</w:t>
						</w:r>
					</w:p>
				</w:tc>
				</#list>
			</w:tr>
			</#if>
			<#list rows as row>
			<w:tr w:rsidR="00B7639C" w14:paraId="3E92656B" w14:textId="77777777" w:rsidTr="00B7639C">
				<#list row as cell>
				<w:tc>
					<w:tcPr>
						<w:tcW w:w="2074" w:type="dxa"/>
					</w:tcPr>
					<w:p w14:paraId="47A07440" w14:textId="084BDC80" w:rsidR="00B7639C" w:rsidRDefault="00B7639C" w:rsidP="00B7639C">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:hint="eastAsia"/>
							</w:rPr>
						</w:pPr>
						<w:r>
							<w:rPr>
								<w:rFonts w:hint="eastAsia"/>
							</w:rPr>
							<w:t>${cell}</w:t>
						</w:r>
					</w:p>
				</w:tc>
				</#list>
			</w:tr>
			</#list>
		</w:tbl>
