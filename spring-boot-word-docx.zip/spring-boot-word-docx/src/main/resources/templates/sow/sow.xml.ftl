		<#if title?has_content>
		<w:p w14:paraId="038E343A" w14:textId="48DADEE2" w:rsidR="00B7639C" w:rsidRPr="00B7639C" w:rsidRDefault="00B7639C" w:rsidP="00B7639C">
			<w:pPr>
				<w:jc w:val="center"/>
				<w:rPr>
					<w:b/>
					<w:sz w:val="28"/>
					<w:rFonts w:hint="eastAsia"/>
				</w:rPr>
			</w:pPr>
			<w:r>
				<w:rPr>
					<w:b/>
					<w:sz w:val="28"/>
					<w:rFonts w:hint="eastAsia"/>
				</w:rPr>
				<w:t>${title}</w:t>
			</w:r>
		</w:p>
		</#if>
		<#if date?has_content>
		<w:p w14:paraId="702154EF" w14:textId="61B04EC5" w:rsidR="005A5567" w:rsidRPr="00B7639C" w:rsidRDefault="00B7639C" w:rsidP="00B7639C">
			<w:pPr>
				<w:rPr>
					<w:rFonts w:hint="eastAsia"/>
				</w:rPr>
			</w:pPr>
			<w:r>
				<w:rPr>
					<w:rFonts w:hint="eastAsia"/>
				</w:rPr>
				<w:t>${date}</w:t>
			</w:r>
		</w:p>
		</#if>
		<#if description?has_content>
		<w:p w14:paraId="702154EF" w14:textId="61B04EC5" w:rsidR="005A5567" w:rsidRPr="00B7639C" w:rsidRDefault="00B7639C" w:rsidP="00B7639C">
			<w:pPr>
				<w:rPr>
					<w:rFonts w:hint="eastAsia"/>
				</w:rPr>
			</w:pPr>
			<w:r>
				<w:rPr>
					<w:rFonts w:hint="eastAsia"/>
				</w:rPr>
				<w:t>${description}</w:t>
			</w:r>
		</w:p>
		</#if>
		${tableXml}
		<w:sectPr w:rsidR="005A5567" w:rsidRPr="00B7639C">
			<w:pgSz w:w="11906" w:h="16838"/>
			<w:pgMar w:top="1440" w:right="1800" w:bottom="1440" w:left="1800" w:header="851" w:footer="992" w:gutter="0"/>
			<w:cols w:space="425"/>
			<w:docGrid w:type="lines" w:linePitch="312"/>
		</w:sectPr>
