package com.example.worddoc.interfaces.rest;

import com.example.worddoc.application.ProtocolExportService;
import com.example.worddoc.application.SowExportService;
import com.example.worddoc.application.WordDocApplicationService;
import com.example.worddoc.application.dto.DocumentResult;
import com.example.worddoc.application.dto.GenerateDocumentCommand;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(WordDownloadController.class)
class WordDownloadControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private WordDocApplicationService wordDocApplicationService;

    @MockBean
    private SowExportService sowExportService;

    @MockBean
    private ProtocolExportService protocolExportService;

    @Test
    void download_ShouldReturn200WithCorrectContentType() throws Exception {
        when(wordDocApplicationService.generate(any(GenerateDocumentCommand.class)))
                .thenReturn(new DocumentResult(new byte[]{0x50, 0x4B, 0x03, 0x04}));

        mockMvc.perform(get("/download")
                        .param("title", "Test")
                        .param("bodyText", "Hello"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"));
    }

    @Test
    void download_ShouldReturnAttachmentHeader() throws Exception {
        when(wordDocApplicationService.generate(any(GenerateDocumentCommand.class)))
                .thenReturn(new DocumentResult(new byte[]{0x50, 0x4B, 0x03, 0x04}));

        mockMvc.perform(get("/download")
                        .param("title", "Test"))
                .andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=document.docx"));
    }

    @Test
    void download_ShouldWorkWithoutParameters() throws Exception {
        when(wordDocApplicationService.generate(any(GenerateDocumentCommand.class)))
                .thenReturn(new DocumentResult(new byte[]{0x50, 0x4B, 0x03, 0x04}));

        mockMvc.perform(get("/download"))
                .andExpect(status().isOk());
    }
}
