package com.example.worddoc.infrastructure.template;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DocumentTypeTemplateResolverTest {

    private final DocumentTypeTemplateResolver resolver = new DocumentTypeTemplateResolver();

    @Test
    void resolve_ShouldPrefixWithDocType() {
        String result = resolver.resolve("sow", "sow.xml.ftl");
        assertEquals("sow/sow.xml.ftl", result);
    }

    @Test
    void resolve_ShouldPrefixWithProtocol() {
        String result = resolver.resolve("protocol", "document.xml.ftl");
        assertEquals("protocol/document.xml.ftl", result);
    }

    @Test
    void resolve_ShouldReturnNameOnly_WhenDocTypeIsNull() {
        String result = resolver.resolve(null, "table.xml.ftl");
        assertEquals("table.xml.ftl", result);
    }

    @Test
    void resolve_ShouldReturnNameOnly_WhenDocTypeIsEmpty() {
        String result = resolver.resolve("", "table.xml.ftl");
        assertEquals("table.xml.ftl", result);
    }

    @Test
    void resolve_SharedTemplate_ShouldNotPrefix() {
        String result = resolver.resolve("", "table.xml.ftl");
        assertEquals("table.xml.ftl", result);
    }
}
