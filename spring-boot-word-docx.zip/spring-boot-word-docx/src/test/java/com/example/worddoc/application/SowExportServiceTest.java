package com.example.worddoc.application;

import com.example.worddoc.application.dto.DocumentResult;
import com.example.worddoc.application.dto.ExportSowCommand;
import com.example.worddoc.domain.model.TableData;
import com.example.worddoc.domain.service.ArchiveEditor;
import com.example.worddoc.domain.service.TemplateRenderer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class SowExportServiceTest {

    private TemplateRenderer templateRenderer;
    private ArchiveEditor archiveEditor;
    private SowExportService service;

    @BeforeEach
    void setUp() {
        templateRenderer = mock(TemplateRenderer.class);
        archiveEditor = mock(ArchiveEditor.class);
        service = new SowExportService(templateRenderer, archiveEditor);
    }

    @Test
    void exportSow_ShouldReturnNonEmptyResult() {
        when(templateRenderer.renderTemplate(anyString(), any()))
                .thenReturn("<xml/>");
        when(archiveEditor.replace(any(), anyString(), any()))
                .thenReturn(new byte[]{0x50, 0x4B, 0x03, 0x04});

        TableData tableData = new TableData(
                Arrays.asList("Col1", "Col2"),
                Arrays.asList(Arrays.asList("A", "B")));
        ExportSowCommand command = new ExportSowCommand("Test", "Desc", "2024-01-01", tableData);
        DocumentResult result = service.exportSow(command);

        assertNotNull(result);
        assertNotNull(result.getContent());
        assertTrue(result.getContent().length > 0);
    }

    @Test
    void exportSow_ShouldRenderTableTemplate() {
        when(templateRenderer.renderTemplate(eq("table.xml.ftl"), any()))
                .thenReturn("<w:tbl/>");
        when(templateRenderer.renderTemplate(eq("sow/sow.xml.ftl"), any()))
                .thenReturn("<w:body><w:tbl/></w:body>");
        when(templateRenderer.renderTemplate(eq("sow/sowdoc.xml.ftl"), any()))
                .thenReturn("<w:document><w:body><w:tbl/></w:body></w:document>");
        when(archiveEditor.replace(any(), anyString(), any()))
                .thenReturn(new byte[]{0x50, 0x4B, 0x03, 0x04});

        TableData tableData = new TableData(
                Arrays.asList("Col1", "Col2"),
                Collections.singletonList(Arrays.asList("A", "B")));
        ExportSowCommand command = new ExportSowCommand("Test", "Desc", "2024-01-01", tableData);
        service.exportSow(command);
    }

    @Test
    void exportSow_ShouldReplaceDocumentXml() {
        when(templateRenderer.renderTemplate(anyString(), any()))
                .thenReturn("<xml/>");
        when(archiveEditor.replace(any(), eq("word/document.xml"), any()))
                .thenReturn(new byte[]{0x50, 0x4B, 0x03, 0x04});

        TableData tableData = new TableData(
                Collections.singletonList("Col1"),
                Collections.singletonList(Collections.singletonList("A")));
        ExportSowCommand command = new ExportSowCommand("Title", "Desc", "2024-06-01", tableData);
        service.exportSow(command);
    }
}
