package com.example.worddoc.infrastructure.template;

import com.example.worddoc.domain.service.TemplatePipelineExecutor;
import com.example.worddoc.domain.service.TemplateRenderer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class FreeMarkerPipelineExecutorTest {

    private TemplateRenderer templateRenderer;
    private TemplatePipelineExecutor executor;

    @BeforeEach
    void setUp() {
        templateRenderer = mock(TemplateRenderer.class);
        executor = new FreeMarkerPipelineExecutor(templateRenderer);
    }

    @Test
    void execute_ShouldRenderSingleStep() {
        when(templateRenderer.renderTemplate(eq("step1.ftl"), anyMap())).thenReturn("<result1/>");

        String result = executor.execute(
                Arrays.asList(new TemplatePipelineExecutor.PipelineStep("step1.ftl", null)),
                new HashMap<>());

        assertEquals("<result1/>", result);
    }

    @Test
    void execute_ShouldPassPreviousOutputToNextStep() {
        Map<String, Object> model = new HashMap<>();
        model.put("input", "hello");

        when(templateRenderer.renderTemplate(eq("step1.ftl"), argThat(m ->
                "hello".equals(((Map<String, Object>) m).get("input")))))
                .thenReturn("<tableXml/>");

        when(templateRenderer.renderTemplate(eq("step2.ftl"), argThat(m -> {
            Map<String, Object> ctx = (Map<String, Object>) m;
            return "<tableXml/>".equals(ctx.get("tableXml"));
        }))).thenReturn("<finalXml/>");

        String result = executor.execute(
                Arrays.asList(
                        new TemplatePipelineExecutor.PipelineStep("step1.ftl", null),
                        new TemplatePipelineExecutor.PipelineStep("step2.ftl", "tableXml")),
                model);

        assertEquals("<finalXml/>", result);
    }

    @Test
    void execute_ShouldHandleThreeStepPipeline() {
        when(templateRenderer.renderTemplate(eq("a.ftl"), anyMap())).thenReturn("<a/>");
        when(templateRenderer.renderTemplate(eq("b.ftl"), anyMap())).thenReturn("<b/>");
        when(templateRenderer.renderTemplate(eq("c.ftl"), anyMap())).thenReturn("<c/>");

        String result = executor.execute(
                Arrays.asList(
                        new TemplatePipelineExecutor.PipelineStep("a.ftl", null),
                        new TemplatePipelineExecutor.PipelineStep("b.ftl", "aXml"),
                        new TemplatePipelineExecutor.PipelineStep("c.ftl", "bXml")),
                new HashMap<>());

        assertEquals("<c/>", result);
    }
}
