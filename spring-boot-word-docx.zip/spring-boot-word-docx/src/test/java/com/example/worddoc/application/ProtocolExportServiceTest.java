package com.example.worddoc.application;

import com.example.worddoc.application.dto.DocumentResult;
import com.example.worddoc.application.dto.ExportProtocolCommand;
import com.example.worddoc.domain.model.TableData;
import com.example.worddoc.domain.service.ArchiveEditor;
import com.example.worddoc.domain.service.TemplateRenderer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ProtocolExportServiceTest {

    private TemplateRenderer templateRenderer;
    private ArchiveEditor archiveEditor;
    private ProtocolExportService service;

    @BeforeEach
    void setUp() {
        templateRenderer = mock(TemplateRenderer.class);
        archiveEditor = mock(ArchiveEditor.class);
        service = new ProtocolExportService(templateRenderer, archiveEditor);
    }

    @Test
    void exportProtocol_ShouldReturnNonEmptyResult() {
        when(templateRenderer.renderTemplate(anyString(), any()))
                .thenReturn("<xml/>");
        when(archiveEditor.replace(any(), anyString(), any()))
                .thenReturn(new byte[]{0x50, 0x4B, 0x03, 0x04});

        TableData tableData = new TableData(
                Arrays.asList("Col1", "Col2"),
                Collections.singletonList(Arrays.asList("A", "B")));
        ExportProtocolCommand command = new ExportProtocolCommand("Title", "Content", tableData);
        DocumentResult result = service.exportProtocol(command);

        assertNotNull(result);
        assertNotNull(result.getContent());
        assertTrue(result.getContent().length > 0);
    }

    @Test
    void exportProtocol_ShouldRenderTableAndIntermediate() {
        when(templateRenderer.renderTemplate(eq("table.xml.ftl"), any()))
                .thenReturn("<w:tbl/>");
        when(templateRenderer.renderTemplate(eq("sow/sow.xml.ftl"), any()))
                .thenReturn("<w:body><w:tbl/></w:body>");
        when(templateRenderer.renderTemplate(eq("protocol/document.xml.ftl"), any()))
                .thenReturn("<w:document><w:body><w:tbl/></w:body></w:document>");
        when(archiveEditor.replace(any(), anyString(), any()))
                .thenReturn(new byte[]{0x50, 0x4B, 0x03, 0x04});

        TableData tableData = new TableData(
                Arrays.asList("Col1", "Col2"),
                Collections.singletonList(Arrays.asList("A", "B")));
        ExportProtocolCommand command = new ExportProtocolCommand("Title", "Content", tableData);
        service.exportProtocol(command);
    }

    @Test
    void exportProtocol_ShouldReplaceDocumentXml() {
        when(templateRenderer.renderTemplate(anyString(), any()))
                .thenReturn("<xml/>");
        when(archiveEditor.replace(any(), eq("word/document.xml"), any()))
                .thenReturn(new byte[]{0x50, 0x4B, 0x03, 0x04});

        TableData tableData = new TableData(
                Collections.singletonList("Col1"),
                Collections.singletonList(Collections.singletonList("A")));
        ExportProtocolCommand command = new ExportProtocolCommand("T", "C", tableData);
        service.exportProtocol(command);
    }
}
