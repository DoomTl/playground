## ADDED Requirements

### Requirement: DDD layered architecture with dependency direction

The system SHALL organize source code into four layers with strict dependency direction: interfaces → application → domain ← infrastructure.

#### Scenario: Interfaces layer depends on application layer
- **WHEN** a class in `interfaces/` package references another class
- **THEN** it SHALL only reference classes in `application/` or Java/Spring standard libraries

#### Scenario: Application layer depends on domain layer
- **WHEN** a class in `application/` package references another class
- **THEN** it SHALL only reference classes in `domain/` or standard Java libraries

#### Scenario: Domain layer has zero external dependencies
- **WHEN** a class in `domain/` package imports another package
- **THEN** it SHALL NOT import any framework, infrastructure, or Spring classes

#### Scenario: Infrastructure layer implements domain interfaces
- **WHEN** a class in `infrastructure/` package references domain concepts
- **THEN** it SHALL implement domain interfaces defined in `domain/`

### Requirement: Domain model uses value objects for primitives

Domain concepts SHALL use typed value objects rather than raw primitives for validation and type safety.

#### Scenario: EmuDimension validates positive values
- **WHEN** an `EmuDimension` value object is created with negative or zero value
- **THEN** it SHALL throw `IllegalArgumentException`

#### Scenario: ImageFileName validates name format
- **WHEN** an `ImageFileName` value object is created with a path containing traversal characters (`..`, `/`, `\`)
- **THEN** it SHALL throw `SecurityException`

### Requirement: External API remains unchanged

The `GET /download` endpoint SHALL maintain the exact same request/response contract after restructuring.

#### Scenario: Download endpoint unchanged
- **WHEN** a GET request is sent to `/download`
- **THEN** the response SHALL be identical to before the restructuring (same content type, same headers, same behavior)

### Requirement: All existing tests pass after restructuring

All existing test scenarios in the `word-doc-generation` spec SHALL continue to pass after the package restructuring.

#### Scenario: ZipUtil tests pass
- **WHEN** `mvn test` is run after restructuring
- **THEN** all 21 ZipUtil tests SHALL pass

#### Scenario: Service tests pass
- **WHEN** `mvn test` is run after restructuring
- **THEN** all 10 WordDocumentService tests SHALL pass

#### Scenario: Controller tests pass
- **WHEN** `mvn test` is run after restructuring
- **THEN** all 3 controller tests SHALL pass
