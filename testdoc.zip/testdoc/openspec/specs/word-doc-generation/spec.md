## MODIFIED Requirements

### Requirement: Package locations changed (internal only)

**FROM:** Flat layer-based packages
- `controller/WordDownloadController.java`
- `model/DocumentData.java`, `model/PreSetImage.java`
- `service/WordDocumentService.java`
- `util/ZipUtil.java`

**TO:** DDD hexagonal packages
- `interfaces/rest/WordDownloadController.java`
- `application/WordDocApplicationService.java`
- `domain/model/DocumentData.java`, `domain/model/PreSetImage.java`, `domain/model/valueobject/EmuDimension.java`
- `infrastructure/template/FreeMarkerTemplateRenderer.java`
- `infrastructure/zip/ZipUtil.java`

**Migration:** All source files move to new packages; `pom.xml`, `application.yml`, template resources unchanged.

## ADDED Requirements

### Requirement: ZipUtil can replace an existing entry in a ZIP byte array

The system SHALL provide a `replaceEntry(zipBytes, entryName, newContent)` method that replaces a named entry in a ZIP byte array and returns the modified ZIP.

#### Scenario: Replace existing entry
- **WHEN** `replaceEntry` is called with a ZIP containing the target entry
- **THEN** the returned ZIP contains the entry with the new content

#### Scenario: Replace non-existent entry throws
- **WHEN** `replaceEntry` is called with an entry name that does not exist in the ZIP
- **THEN** the method SHALL throw `IllegalArgumentException`

### Requirement: ZipUtil can add a new entry to a ZIP byte array

The system SHALL provide a `addEntry(zipBytes, entryName, content)` method that adds a new named entry to a ZIP byte array and returns the modified ZIP.

#### Scenario: Add new entry to valid ZIP
- **WHEN** `addEntry` is called with a valid ZIP and a new entry name
- **THEN** the returned ZIP contains the original entries plus the new entry

#### Scenario: Add duplicate entry throws
- **WHEN** `addEntry` is called with an entry name that already exists in the ZIP
- **THEN** the method SHALL throw `IllegalArgumentException`

### Requirement: ZipUtil SHALL reject path traversal in entry names

All ZipUtil methods SHALL validate entry names against path traversal attacks before any ZIP operation.

#### Scenario: Reject parent directory traversal
- **WHEN** entry name contains `../` or `..\\`
- **THEN** the method SHALL throw `SecurityException`

#### Scenario: Reject absolute Unix paths
- **WHEN** entry name starts with `/`
- **THEN** the method SHALL throw `SecurityException`

#### Scenario: Reject absolute Windows paths
- **WHEN** entry name starts with a drive letter (e.g., `C:/`)
- **THEN** the method SHALL throw `SecurityException`

#### Scenario: Reject null byte injection
- **WHEN** entry name contains `\0`
- **THEN** the method SHALL throw `SecurityException`

#### Scenario: Reject unicode path traversal variants
- **WHEN** entry name contains Unicode characters that normalize to `..` (e.g., `\u2025`)
- **THEN** the method SHALL throw `SecurityException` after NFC normalization

### Requirement: ZipUtil SHALL reject ZIP bomb attacks

All ZipUtil methods SHALL validate ZIP content against compression bomb attacks during streaming.

#### Scenario: Reject excessive compression ratio
- **WHEN** any entry has uncompressed/compressed ratio > 100:1
- **THEN** the method SHALL throw `SecurityException`

#### Scenario: Reject too many entries
- **WHEN** the ZIP contains more than 10,000 entries
- **THEN** the method SHALL throw `SecurityException`

#### Scenario: Reject oversized total content
- **WHEN** total uncompressed size exceeds 1 GB
- **THEN** the method SHALL throw `SecurityException`

### Requirement: ZipUtil SHALL reject symbolic link entries

All ZipUtil methods SHALL reject ZIP entries that are Unix symbolic links.

#### Scenario: Reject symlink entry
- **WHEN** a ZIP entry is a symbolic link
- **THEN** the method SHALL throw `SecurityException`

### Requirement: ZipUtil SHALL reject duplicate entries with different casing

All ZipUtil methods SHALL reject entries whose names differ only in letter casing to prevent file system overwrite attacks.

#### Scenario: Reject case-insensitive duplicate
- **WHEN** the ZIP contains both `Readme.txt` and `readme.txt`
- **THEN** the method SHALL throw `SecurityException`

### Requirement: FTL template renders document.xml with text and images

The `document.xml.ftl` template SHALL render valid OOXML containing title text, body text, and image drawing elements with correct relationship references.

#### Scenario: Render document with title and body
- **WHEN** the template is rendered with a non-empty title and bodyText
- **THEN** the output XML SHALL contain both text elements in <w:t> nodes

#### Scenario: Render document with image drawings
- **WHEN** the template is rendered with a non-empty images list
- **THEN** the output XML SHALL contain <w:drawing> elements with correct <a:blip r:embed> attributes referencing `rIdImg{index}`

#### Scenario: Render document without images
- **WHEN** the template is rendered with an empty images list
- **THEN** the output XML SHALL NOT contain any <w:drawing> elements

### Requirement: FTL template renders document.xml.rels with image relationships

The `document.xml.rels.ftl` template SHALL render valid OOXML relationships XML with image target paths.

#### Scenario: Render rels with image targets
- **WHEN** the template is rendered with image data
- **THEN** the output XML SHALL contain <Relationship> elements with Target="media/{fileName}" for each image

#### Scenario: Render rels without images
- **WHEN** the template is rendered with an empty images list
- **THEN** the output XML SHALL contain only the default style relationship

### Requirement: WordDocumentService generates a valid .docx from DocumentData

The service SHALL orchestrate FTL rendering, ZIP manipulation, and image injection to produce a valid .docx byte array.

#### Scenario: Generated output is a valid ZIP
- **WHEN** `generateDocument` is called with valid DocumentData
- **THEN** the returned byte array SHALL be a valid ZIP archive

#### Scenario: Output contains required OOXML parts
- **WHEN** `generateDocument` returns a .docx
- **THEN** the ZIP SHALL contain `word/document.xml`, `word/_rels/document.xml.rels`, and `[Content_Types].xml`

#### Scenario: Output includes image in media directory
- **WHEN** `generateDocument` is called with images
- **THEN** the ZIP SHALL contain `word/media/{image.fileName}` with the correct image bytes

#### Scenario: Output document contains rendered title
- **WHEN** `generateDocument` is called with a title
- **THEN** `word/document.xml` in the output SHALL contain the title text

#### Scenario: Output rels contains image relationships
- **WHEN** `generateDocument` is called with images
- **THEN** `word/_rels/document.xml.rels` in the output SHALL contain relationship entries for each image

### Requirement: Controller returns .docx as downloadable attachment

The `GET /download` endpoint SHALL return a generated Word document as a downloadable file.

#### Scenario: Download returns 200 with correct content type
- **WHEN** a GET request is made to `/download`
- **THEN** the response SHALL have status 200 and Content-Type `application/vnd.openxmlformats-officedocument.wordprocessingml.document`

#### Scenario: Download returns attachment header
- **WHEN** a GET request is made to `/download`
- **THEN** the response SHALL have Content-Disposition `attachment; filename=document.docx`
