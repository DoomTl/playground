## Context

The DDD restructure introduced value objects (`EmuDimension`, `ImageFileName`, `RelationshipId`) and refactored `PreSetImage` to use them. During this process, helper methods and constructors were added that are never called from Java code or FreeMarker templates. Separately, the codebase contains ~120 lines of boilerplate (getters, setters, constructors, equals/hashCode) across 5 POJO/value object classes.

Lombok is the standard Java solution for eliminating this boilerplate. It is annotation-processor-based, has zero runtime overhead, and is widely adopted in Spring Boot projects.

## Goals / Non-Goals

**Goals:**
- Remove all dead code identified by static analysis (unused constructors, methods, imports)
- Introduce Lombok to reduce boilerplate on POJO and value object classes
- All 34 existing tests must pass without changes
- No behavioral changes whatsoever

**Non-Goals:**
- No architectural changes (packages, layers, dependency flow stay as-is)
- No new features or API changes
- No changes to FreeMarker templates or classpath resources

## Decisions

1. **Lombok `@Value` for immutable DTOs and value objects**: `GenerateDocumentCommand`, `DocumentResult`, `EmuDimension`, `ImageFileName` are naturally immutable — `@Value` generates `@Getter`, `@AllArgsConstructor`, `@EqualsAndHashCode`, `@ToString`, and makes fields `private final`. Custom constructor logic (validation in `EmuDimension`/`ImageFileName`, `toDomain()` in `GenerateDocumentCommand`) is preserved by using `@Value` with a custom `@AllArgsConstructor(access = PRIVATE)` on value objects.

2. **`@Data` for `DocumentData`**: This class has mutable fields and needs a no-arg constructor for FreeMarker bean access. `@Data` generates `@Getter`, `@Setter`, `@EqualsAndHashCode`, `@ToString`, `@RequiredArgsConstructor`. Add explicit `@NoArgsConstructor` for FreeMarker compatibility.

3. **Partial Lombok for `PreSetImage`**: Has custom logic wrapping primitives into value objects. Use `@Data` for getters/setters/equals/hashCode, but keep custom constructors and setters that perform `ImageFileName.of()` / `EmuDimension.of()` wrapping. Remove dead methods.

4. **Lombok scope — test code excluded**: Lombok is for production source only. Test files keep their existing code style.

5. **Lombok version**: 1.18.30 (latest compatible with Java 8 and Spring Boot 2.7.18).

## Risks / Trade-offs

- **[IDE setup]** Developers without Lombok plugin in their IDE will see compile errors in their editor — mitigated by Lombok being standard in Spring Boot ecosystem; `mvn compile` works without plugins since annotation processors run at build time.
- **[Delombok]** If Lombok is ever removed, `delombok` can regenerate the code — low risk since Lombok has been stable for over a decade.
- **[Oversight on unused removal]** Might miss a method that IS used (e.g., via reflection or FTL) — mitigated by running all 34 tests after each change.
