## ADDED Requirements

No new requirements — this is a pure cleanup and refactoring change.

## MODIFIED Requirements

None — no behavioral changes.

## REMOVED Requirements

None

## RENAMED Requirements

None
