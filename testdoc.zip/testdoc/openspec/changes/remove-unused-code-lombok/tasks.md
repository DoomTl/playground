## 1. Build Configuration

- [x] 1.1 Add Lombok 1.18.30 dependency to `pom.xml` (compile scope, annotation processor path)

## 2. Domain Model Cleanup — Value Objects

- [x] 2.1 Apply Lombok `@Value` to `EmuDimension.java`: remove manual getter, equals, hashCode, toString; remove unused `fromPixels()` factory method
- [x] 2.2 Apply Lombok `@Value` to `ImageFileName.java`: remove manual getter, equals, hashCode, toString

## 3. Domain Model Cleanup — Entities

- [x] 3.1 Apply Lombok `@Data` + `@NoArgsConstructor` to `DocumentData.java`: remove manual getters, setters, constructors, toString
- [x] 3.2 Clean up `PreSetImage.java`: remove dead methods (no-arg constructor, `getFileNameAsString()`, `getWidthEmuValue()`, `getHeightEmuValue()`, all 4 setters, the `(ImageFileName, byte[], EmuDimension, EmuDimension)` constructor); apply Lombok `@Data` with manual custom constructors and value-object wrapping setters

## 4. Application Layer Cleanup

- [x] 4.1 Apply Lombok `@Value` to `GenerateDocumentCommand.java`: remove manual getters, constructor; keep `toDomain()` custom method
- [x] 4.2 Apply Lombok `@Value` to `DocumentResult.java`: remove manual getter, constructor

## 5. Test Cleanup

- [x] 5.1 Remove unused imports from `WordDocApplicationServiceTest.java` (`freemarker.template.Configuration`, `java.io.StringWriter`, `java.util.Arrays`)

## 6. Housekeeping

- [x] 6.1 Remove empty `interfaces/rest/dto/` directory (no classes were placed there)
- [x] 6.2 Verify compilation and all 34 tests pass
- [x] 6.3 Verify JAR builds successfully
