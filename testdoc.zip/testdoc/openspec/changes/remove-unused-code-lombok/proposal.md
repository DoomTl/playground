## Why

After the DDD hexagonal refactoring, several classes and methods became dead code (unused constructors, getters, setters, and a factory method). Additionally, the codebase has significant boilerplate (getters, setters, constructors, equals/hashCode) that Lombok can eliminate, reducing noise and potential errors.

## What Changes

- Remove unused constructors, methods, and value object classes
- Remove unused imports from test files
- Add Lombok dependency to `pom.xml`
- Replace boilerplate code with Lombok annotations (`@Data`, `@Value`, `@NoArgsConstructor`, `@AllArgsConstructor`)
- Keep custom constructors and validation that wrap value objects (`ImageFileName.of()`, `EmuDimension.of()`)

## Capabilities

### New Capabilities

None — this is a cleanup/refactoring change, not a feature addition.

### Modified Capabilities

None — no requirements are changing. All behavior is preserved.

## Impact

- `pom.xml`: add Lombok dependency and annotation processor path
- Domain model classes: `DocumentData`, `PreSetImage`, `EmuDimension`, `ImageFileName` — simplified with Lombok
- Application DTOs: `GenerateDocumentCommand`, `DocumentResult` — simplified with Lombok
- Infrastructure and interfaces layers: no changes needed (already clean)
- Zero behavioral changes: all 34 existing tests must continue passing
