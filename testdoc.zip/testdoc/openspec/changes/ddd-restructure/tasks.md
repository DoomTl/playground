## 1. Infrastructure Layer (ports & adapters)

- [ ] 1.1 Create package directories: `domain/model/valueobject/`, `domain/service/`, `application/dto/`, `infrastructure/template/`, `infrastructure/config/`, `interfaces/rest/dto/`
- [ ] 1.2 Move `ZipUtil` to `infrastructure/zip/ZipUtil.java` — update package declaration, keep class unchanged
- [ ] 1.3 Create `infrastructure/template/FreeMarkerTemplateRenderer.java` — extract template rendering from `WordDocumentService` into its own infrastructure class
- [ ] 1.4 Create `infrastructure/config/BeanConfiguration.java` — Spring `@Configuration` that wires domain services with infrastructure implementations

## 2. Domain Layer (pure business logic)

- [ ] 2.1 Create value object `EmuDimension` — wraps `long` value, validates positive, provides `getValue()` and factory method `fromPixels(px, dpi)`
- [ ] 2.2 Create value object `ImageFileName` — validates safe filename (no path traversal), stores original name string
- [ ] 2.3 Create value object `RelationshipId` — generates auto-increment IDs like `rIdImg1`, `rIdImg2`
- [ ] 2.4 Move `DocumentData` and `PreSetImage` to `domain/model/` — update package declarations
- [ ] 2.5 Refactor `PreSetImage` to use `EmuDimension` and `ImageFileName` value objects
- [ ] 2.6 Create `domain/service/TemplateRenderer` interface — port for template rendering (method: `renderTemplate(name, model) → String`)
- [ ] 2.7 Create `domain/service/DocxAssembler` — domain service that orchestrates template rendering + ZIP operations (replaces current `WordDocumentService` logic)

## 3. Application Layer (use case orchestration)

- [ ] 3.1 Create `application/dto/GenerateDocumentCommand.java` — input DTO with title, bodyText, image refs
- [ ] 3.2 Create `application/dto/DocumentResult.java` — output DTO wrapping `byte[]` docx content
- [ ] 3.3 Create `application/WordDocApplicationService.java` — thin orchestrator: receives command, converts to domain objects, calls `DocxAssembler`, returns result

## 4. Interfaces Layer (HTTP controllers)

- [ ] 4.1 Move `WordDownloadController` to `interfaces/rest/WordDownloadController.java` — update package and imports
- [ ] 4.2 Create `interfaces/rest/dto/DocumentDownloadRequest.java` — request mapping DTO (optional params)
- [ ] 4.3 Refactor controller to inject `WordDocApplicationService` instead of `WordDocumentService`

## 5. Test Updates

- [ ] 5.1 Update `ZipUtilTest.java` and `ZipUtilTestHelper.java` — change package to match new `infrastructure.zip` location
- [ ] 5.2 Update `WordDocumentServiceTest.java` — rename/repackage to match new `application/` and `infrastructure/` classes
- [ ] 5.3 Update `WordDownloadControllerTest.java` — update import paths to `interfaces/rest/`
- [ ] 5.4 Move `NamespaceContextMap.java` to match test package structure

## 6. Verify

- [ ] 6.1 Run `mvn compile` — confirm compilation passes
- [ ] 6.2 Run `mvn test` — confirm all 34 tests pass
- [ ] 6.3 Run `mvn clean package` — confirm JAR builds successfully
