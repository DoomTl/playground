## Context

Current project uses a flat layer-based package layout (`controller/`, `service/`, `model/`, `util/`) common in Spring Boot starter projects. This structure mixes domain concepts with infrastructure concerns — e.g., `WordDocumentService` directly depends on FreeMarker's `Configuration` and `ZipUtil`, blurring the line between business logic and technical implementation.

The DDD restructuring re-organizes into a hexagonal architecture with four explicit layers, each with a clear dependency direction: Interfaces → Application → Domain ← Infrastructure.

## Goals / Non-Goals

**Goals:**
- DDD-aligned package structure with explicit bounded contexts
- Domain model isolated from framework and infrastructure concerns
- Domain services depend only on domain model interfaces, not on concrete implementations
- Infrastructure implementations wired via dependency injection
- All existing tests pass without behavior changes
- Application external API (`/download` endpoint) unchanged

**Non-Goals:**
- No new features or behavior changes
- No new dependencies
- No database or persistence layer (not needed for current requirements)
- No CQRS or event sourcing (over-engineering for this scale)

## Decisions

1. **Hexagonal (ports & adapters) over layered DDD**: Domain defines interfaces (ports), infrastructure implements them (adapters). Application orchestrates use cases. Interfaces layer handles HTTP concerns. This allows swapping infrastructure (e.g., replace FreeMarker with another template engine) without affecting domain.

2. **Value Objects for domain primitives**: `EmuDimension`, `RelationshipId`, `ImageFileName` as value objects with self-validation. Avoids primitive obsession and centralizes validation logic in the domain.

3. **Package by domain concept, not by layer role**: Each domain concept lives in a single package. For example, `ImageData` and `EmuDimension` co-locate in `domain/model/valueobject/`, not split across `model/` and `util/`.

4. **Application service as thin orchestrator**: `WordDocApplicationService` receives DTOs from interfaces layer, converts to domain objects, calls domain service, collects result. No business logic in application layer — just coordination and transaction management.

5. **Infrastructure depends on domain, not vice versa**: `FreeMarkerTemplateRenderer` implements a `TemplateRenderer` interface defined in domain. `ZipUtil` implements a `DocxArchive` interface defined in domain. Domain is framework-free and testable without Spring.

### Target Package Layout

```
com.example.worddoc
├── WordDocApplication.java
│
├── interfaces/                          # Inbound adapters (HTTP)
│   └── rest/
│       ├── WordDownloadController.java
│       └── dto/
│           └── DocumentDownloadRequest.java
│
├── application/                         # Use case orchestration
│   ├── WordDocApplicationService.java
│   └── dto/
│       ├── DocumentResult.java
│       └── GenerateDocumentCommand.java
│
├── domain/                              # Core business logic
│   ├── model/
│   │   ├── DocumentData.java            # Aggregate root
│   │   ├── PreSetImage.java
│   │   └── valueobject/
│   │       ├── EmuDimension.java
│   │       ├── RelationshipId.java
│   │       └── ImageFileName.java
│   └── service/
│       ├── WordDocumentGenerator.java   # Domain service interface
│       └── DefaultWordDocumentGenerator.java  # Domain service impl
│
└── infrastructure/                      # Outbound adapters
    ├── template/
    │   └── FreeMarkerTemplateRenderer.java
    ├── zip/
    │   └── ZipUtil.java
    └── config/
        └── BeanConfiguration.java
```

### Dependency Flow

```
interfaces (HTTP)  ──→  application  ──→  domain (interfaces)
                                               ↑
                                         infrastructure (implements)
```

- `interfaces/` depends on `application/` and Spring Web
- `application/` depends on `domain/`
- `domain/` depends on NOTHING (pure Java)
- `infrastructure/` depends on `domain/` (implements its interfaces) and technical libraries (FreeMarker, java.util.zip)

## Risks / Trade-offs

- **[Coupling] Domain currently small** → For a 6-class domain, DDD overhead might feel excessive. However, the structure future-proofs the project for more complex requirements.
- **[Migration effort] Package refactoring across tests** → All test imports need updating. Solved by running them immediately after refactoring.
- **[Over-engineering] Port/adapter interfaces** → Interfaces like `TemplateRenderer` and `DocxArchive` may feel like indirection for single-implementation cases. Acceptable trade-off for clean dependency direction.
- **[Learning curve] DDD concepts** → Value objects and domain services add conceptual overhead for new contributors. Mitigated by clear package naming and consistent conventions.
