## Why

Current project uses a flat package-by-layer structure (`controller/`, `service/`, `model/`, `util/`), mixing domain logic with infrastructure concerns. As the project grows, this leads to tight coupling and unclear boundaries. DDD restructuring aligns package boundaries with business concepts, making the code more maintainable and adaptable to new features.

## What Changes

- Restructure all packages from flat layer-based to DDD hexagonal architecture
- Move `WordDownloadController` → `interfaces/rest/`
- Extract domain model with explicit value objects → `domain/model/` and `domain/model/valueobject/`
- Extract document generation domain logic → `domain/service/`
- Create `application/` layer for use case orchestration with DTOs
- Move template rendering and ZIP utils → `infrastructure/`
- Keep all tests passing and APIs unchanged (**no breaking changes**)
- Separate configuration into `infrastructure/config/`

## Capabilities

### New Capabilities
- `ddd-package-structure`: DDD-aligned package layout with clear bounded contexts separating interface, application, domain, and infrastructure concerns.

### Modified Capabilities
- `word-doc-generation`: Package paths change; class names and external API behavior remain identical.

## Impact

- All Java source files move to new packages (internal restructuring only)
- `pom.xml` unchanged (no new dependencies)
- `application.yml` unchanged
- Template resources unchanged
- All existing tests must pass without modification after package updates
- No API changes: `/download` endpoint, request params, response format all identical
