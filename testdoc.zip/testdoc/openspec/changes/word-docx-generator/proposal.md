## Why

Need a Spring Boot 2 service that dynamically generates Word (.docx) documents from FreeMarker templates with text and images, exposed via a download endpoint. Manual Word document creation is error-prone and doesn't scale.

## What Changes

- New Spring Boot 2 application (`spring-boot-word-docx`)
- `GET /download` endpoint returns a generated .docx file as a downloadable attachment
- Word document generated from FTL templates for `word/document.xml` and `word/_rels/document.xml.rels`
- Images inserted into `word/media/` and referenced via relationship IDs in the XML
- Self-built `ZipUtil` with comprehensive security protections against path traversal, ZIP bombs, symlinks, and other ZIP-based attacks
- TDD-driven development — all core logic covered by tests first

## Capabilities

### New Capabilities
- `word-doc-generation`: Generate .docx files from FTL templates with dynamic text and multiple images, using in-memory ZIP manipulation via self-built ZipUtil with full security hardening.

### Modified Capabilities

<!-- None — this is a new project -->

## Impact

- New Maven project with Spring Boot 2.7.x, FreeMarker, JUnit 5
- No external ZIP library — self-built `ZipUtil` with security validation
- `template.docx` as binary resource serving as ZIP base shell
- Pre-set images stored under `src/main/resources/images/`
- Security validations on all ZIP entry operations
