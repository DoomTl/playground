## 1. Project Setup

- [x] 1.1 Create Maven project with pom.xml (Spring Boot 2.7.x, FreeMarker, JUnit 5)
- [x] 1.2 Create package structure: controller/, service/, model/, util/
- [x] 1.3 Create minimal template.docx binary resource with [Content_Types].xml, _rels/.rels, word/document.xml, word/_rels/document.xml.rels

## 2. ZipUtil Safety Validations (TDD)

- [x] 2.1 RED: Write test `replaceEntry_ShouldRejectPathTraversal` — watch it fail
- [x] 2.2 GREEN: Implement `validateEntryName()` with path traversal, absolute path, drive letter, null byte, NFC normalization checks
- [x] 2.3 RED: Write test `shouldRejectSymlinkEntry` — watch it fail
- [x] 2.4 GREEN: Add symlink detection in ZIP stream validation
- [x] 2.5 RED: Write test `shouldRejectZipBombHighCompression` — watch it fail
- [x] 2.6 GREEN: Add compression ratio, entry count, and total size checks
- [x] 2.7 RED: Write test `shouldRejectDuplicateNameCaseDifferent` — watch it fail
- [x] 2.8 GREEN: Add case-insensitive duplicate detection

## 3. ZipUtil Core Operations (TDD)

- [x] 3.1 RED: Write test `replaceEntry_ShouldReplaceExistingEntry` — watch it fail
- [x] 3.2 GREEN: Implement `replaceEntry(zipBytes, entryName, newContent)` return modified ZIP
- [x] 3.3 RED: Write test `replaceEntry_ShouldThrowWhenEntryNotFound` — watch it fail
- [x] 3.4 GREEN: Add IllegalArgumentException for non-existent entry
- [x] 3.5 RED: Write test `addEntry_ShouldAddNewEntry` — watch it fail
- [x] 3.6 GREEN: Implement `addEntry(zipBytes, entryName, content)` return modified ZIP
- [x] 3.7 RED: Write test `addEntry_ShouldThrowWhenEntryExists` — watch it fail
- [x] 3.8 GREEN: Add duplicate entry name check

## 4. Model & FTL Templates

- [x] 4.1 Create model classes: `DocumentData`, `PreSetImage`
- [x] 4.2 Create `document.xml.ftl` with title, bodyText, and image drawing loop
- [x] 4.3 Create `document.xml.rels.ftl` with image relationship loop using img_index
- [x] 4.4 Add pre-set images to `src/main/resources/images/`

## 5. FTL Rendering Tests (TDD)

- [x] 5.1 RED: Write test for document.xml with title and body text renders correct XML — watch it fail
- [x] 5.2 GREEN: Implement FreeMarker template rendering configuration
- [x] 5.3 RED: Write test for document.xml with images renders drawing elements with correct r:embed — watch it fail
- [x] 5.4 GREEN: Finalize document.xml.ftl to pass image drawing assertions
- [x] 5.5 RED: Write test for document.xml.rels with images renders relationship entries — watch it fail
- [x] 5.6 GREEN: Finalize document.xml.rels.ftl to pass relationship assertions

## 6. WordDocumentService (TDD)

- [x] 6.1 RED: Write test `generate_ShouldReturnValidZip` — watch it fail
- [x] 6.2 GREEN: Implement `generateDocument()` orchestrating FTL + ZipUtil operations
- [x] 6.3 RED: Write test `generate_ShouldContainExpectedEntries` — watch it fail
- [x] 6.4 GREEN: Ensure output ZIP contains all required OOXML parts
- [x] 6.5 RED: Write test `generate_ShouldRenderTitleInDocumentXml` — watch it fail
- [x] 6.6 GREEN: Wire FTL data model to template correctly
- [x] 6.7 RED: Write test `generate_ShouldHaveImageRelsAndMedia` — watch it fail
- [x] 6.8 GREEN: Implement image injection into word/media/ and rels generation
- [x] 6.9 RED: Write test `generate_WithEmptyImages_ShouldNotContainDrawings` — watch it fail
- [x] 6.10 GREEN: Handle empty images list edge case

## 7. Controller

- [x] 7.1 Create `WordDownloadController` with GET /download endpoint
- [x] 7.2 Add response headers: Content-Type and Content-Disposition

## 8. Final Verification

- [x] 8.1 Run all tests — confirm all pass (34/34 passed)
- [x] 8.2 Build project with `mvn clean package` — confirm success
- [ ] 8.3 Manual smoke test: hit /download endpoint, verify .docx opens correctly in Word
