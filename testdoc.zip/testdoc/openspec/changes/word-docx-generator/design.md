## Context

Spring Boot 2 application generating Word (.docx) documents on-the-fly. .docx files are ZIP archives containing XML parts. The approach uses FreeMarker FTL templates to render `word/document.xml` and `word/_rels/document.xml.rels`, then manipulates the ZIP in-memory with a self-built security-hardened ZipUtil. Images are pre-set in `src/main/resources/images/` and injected during generation.

## Goals / Non-Goals

**Goals:**
- GET `/download` endpoint returning a valid .docx as attachment
- FTL-driven XML generation for document body and relationships
- Multiple pre-set images injectable into the document
- Self-built ZipUtil with security hardening (path traversal, ZIP bomb, symlink, null byte, etc.)
- TDD — all core logic covered by tests first
- Pure in-memory ZIP operations (no temp files)

**Non-Goals:**
- User-uploaded images (images are pre-set in resources)
- POST / multipart upload API
- Editing existing documents (always generate from template.docx)
- Browser-based preview
- Complex formatting beyond text + images (tables, charts, headers/footers)

## Decisions

1. **Self-built ZipUtil over Hutool**: Full control over security validation per entry. Hutool's ZipUtil lacks path traversal and ZIP bomb detection. Our implementation adds 10+ security checks while Hutool would require wrapping anyway.

2. **In-memory byte[] over temp files**: Simplifies testing (no disk cleanup), works for the expected document sizes (< 10MB). The trade-off is higher memory usage for very large documents, but that's acceptable given the use case.

3. **FTL controls rId generation**: Using FreeMarker's built-in `img_index` loop variable to generate `rIdImg1`, `rIdImg2`, etc. Keeps the FTL self-contained and avoids passing externally-computed rIds. The Service layer only provides image data; the template owns the XML structure.

4. **XML parsing assertion over string matching in tests**: Using `javax.xml.parsers.DocumentBuilder` + XPath to verify FTL output. More robust than string contains — catches malformed XML, verifies correct attribute placement, and survives formatting changes.

5. **template.docx as binary resource**: A minimal valid .docx ZIP with `[Content_Types].xml`, `_rels/.rels`, and empty `word/document.xml`. Kept under version control. Startup-time generation was considered but adds complexity for no benefit since the template is static.

6. **NFC normalization for entry names**: Prevents Unicode normalization attacks (e.g., `\u2025` rendering as `..` in some filesystem contexts). Applied early in `validateEntryName()` before any path traversal check.

## Risks / Trade-offs

- **[Security] Entry name validation bypass via encoding variants** → NFC normalization + explicit character deny list covers known variants. Regular audit recommended as new bypass techniques emerge.
- **[Memory] Large documents or many images** → 1GB total uncompressed limit and 100MB per-entry cap prevent OOM. For production with larger documents, switch to temp-file mode.
- **[Performance] FTL rendering for every request** → FreeMarker is fast (< 5ms for typical templates). No caching needed at this scale. Revisit if throughput exceeds 100 req/s.
- **[Maintenance] OOXML complexity** → Only basic paragraph + image drawing is supported. Adding tables, charts, or advanced formatting requires FTL template changes and deeper OOXML knowledge.
- **[False positives] Compression ratio check** → Legitimate files with high compression (e.g., already-compressed images in ZIP) could trigger the bomb detector. The 100:1 ratio threshold is generous enough to avoid false positives for typical PNG/JPEG content.
