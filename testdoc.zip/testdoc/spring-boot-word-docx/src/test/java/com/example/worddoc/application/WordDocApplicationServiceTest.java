package com.example.worddoc.application;

import com.example.worddoc.application.dto.GenerateDocumentCommand;
import com.example.worddoc.domain.model.DocumentData;
import com.example.worddoc.domain.model.PreSetImage;
import com.example.worddoc.domain.service.ArchiveEditor;
import com.example.worddoc.domain.service.DocxAssembler;
import com.example.worddoc.domain.service.TemplateRenderer;
import com.example.worddoc.infrastructure.template.FreeMarkerTemplateRenderer;
import com.example.worddoc.infrastructure.zip.ZipArchiveEditor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.*;

class WordDocApplicationServiceTest {

    private TemplateRenderer templateRenderer;
    private ArchiveEditor archiveEditor;
    private DocxAssembler docxAssembler;
    private WordDocApplicationService service;

    @BeforeEach
    void setUp() throws Exception {
        FreeMarkerConfigurer configurer = new FreeMarkerConfigurer();
        configurer.setTemplateLoaderPath("classpath:/templates/");
        configurer.setDefaultEncoding("UTF-8");
        configurer.afterPropertiesSet();
        templateRenderer = new FreeMarkerTemplateRenderer(configurer);
        archiveEditor = new ZipArchiveEditor();
        docxAssembler = new DocxAssembler(templateRenderer, archiveEditor);
        service = new WordDocApplicationService(docxAssembler);
    }

    // ═══════════════════════════════════════════════════════════════
    // Section 5: FTL Rendering Tests (using XML parsing assertions)
    // ═══════════════════════════════════════════════════════════════

    @Test
    void documentXml_ShouldRenderTitleAndBodyText() throws Exception {
        DocumentData data = new DocumentData();
        data.setTitle("Test Title");
        data.setBodyText("Test Body Content");
        data.setImages(new ArrayList<>());

        String xml = renderTemplate("document.xml.ftl", data);

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder builder = dbf.newDocumentBuilder();
        org.w3c.dom.Document doc = builder.parse(
                new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        XPath xpath = XPathFactory.newInstance().newXPath();
        xpath.setNamespaceContext(new NamespaceContextMap(
                "w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main"));

        String titleText = xpath.evaluate(
                "//w:t[text()='Test Title']", doc);
        assertEquals("Test Title", titleText);

        String bodyText = xpath.evaluate(
                "//w:t[text()='Test Body Content']", doc);
        assertEquals("Test Body Content", bodyText);
    }

    @Test
    void documentXml_ShouldRenderImageDrawings() throws Exception {
        byte[] dummyImage = new byte[]{0, 1, 2, 3};
        List<PreSetImage> images = new ArrayList<>();
        images.add(new PreSetImage("img1.png", dummyImage, 914400L, 914400L));
        images.add(new PreSetImage("img2.png", dummyImage, 1828800L, 914400L));

        DocumentData data = new DocumentData();
        data.setImages(images);

        String xml = renderTemplate("document.xml.ftl", data);

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder builder = dbf.newDocumentBuilder();
        org.w3c.dom.Document doc = builder.parse(
                new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        XPath xpath = XPathFactory.newInstance().newXPath();
        xpath.setNamespaceContext(new NamespaceContextMap(
                "w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
                "a", "http://schemas.openxmlformats.org/drawingml/2006/main",
                "r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships"));

        String blip1 = xpath.evaluate(
                "//a:blip/@r:embed",
                doc);
        assertEquals("rIdImg1", blip1);
    }

    @Test
    void documentXml_ShouldNotContainDrawingsWhenNoImages() throws Exception {
        DocumentData data = new DocumentData();
        data.setTitle("No Images");
        data.setImages(new ArrayList<>());

        String xml = renderTemplate("document.xml.ftl", data);

        assertFalse(xml.contains("w:drawing"),
                "Should not contain drawing elements when no images");
        assertFalse(xml.contains("rIdImg"),
                "Should not contain image rIds when no images");
    }

    @Test
    void documentXmlRels_ShouldRenderImageRelationships() throws Exception {
        byte[] dummyImage = new byte[]{0, 1, 2, 3};
        List<PreSetImage> images = new ArrayList<>();
        images.add(new PreSetImage("logo.png", dummyImage, 914400L, 914400L));
        images.add(new PreSetImage("banner.png", dummyImage, 1828800L, 914400L));

        DocumentData data = new DocumentData();
        data.setImages(images);

        String xml = renderTemplate("document.xml.rels.ftl", data);

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder builder = dbf.newDocumentBuilder();
        org.w3c.dom.Document doc = builder.parse(
                new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        XPath xpath = XPathFactory.newInstance().newXPath();
        xpath.setNamespaceContext(new NamespaceContextMap(
                "r", "http://schemas.openxmlformats.org/package/2006/relationships"));

        String target1 = xpath.evaluate(
                "//r:Relationship[@Id='rIdImg1']/@Target", doc);
        assertEquals("media/logo.png", target1);

        String target2 = xpath.evaluate(
                "//r:Relationship[@Id='rIdImg2']/@Target", doc);
        assertEquals("media/banner.png", target2);
    }

    @Test
    void documentXmlRels_ShouldNotContainImageRelsWhenNoImages() throws Exception {
        DocumentData data = new DocumentData();
        data.setImages(new ArrayList<>());

        String xml = renderTemplate("document.xml.rels.ftl", data);

        assertFalse(xml.contains("rIdImg"),
                "Should not contain image relationships when no images");
    }

    // ═══════════════════════════════════════════════════════════════
    // Section 6: WordDocApplicationService Integration Tests
    // ═══════════════════════════════════════════════════════════════

    @Test
    void generate_ShouldReturnValidZip() {
        GenerateDocumentCommand command = new GenerateDocumentCommand("Test", "Body");
        byte[] result = service.generate(command).getContent();

        assertNotNull(result);
        assertTrue(result.length > 0);
        assertTrue(isValidZip(result));
    }

    @Test
    void generate_ShouldContainExpectedEntries() throws IOException {
        GenerateDocumentCommand command = new GenerateDocumentCommand("Test", "Body");
        byte[] result = service.generate(command).getContent();

        List<String> entryNames = listZipEntries(result);
        assertTrue(entryNames.contains("word/document.xml"));
        assertTrue(entryNames.contains("word/_rels/document.xml.rels"));
        assertTrue(entryNames.contains("[Content_Types].xml"));
    }

    @Test
    void generate_ShouldRenderTitleInDocumentXml() throws Exception {
        GenerateDocumentCommand command = new GenerateDocumentCommand("HelloWorld", "Body");
        byte[] result = service.generate(command).getContent();
        byte[] docXmlBytes = readZipEntry(result, "word/document.xml");
        String docXml = new String(docXmlBytes, StandardCharsets.UTF_8);

        assertTrue(docXml.contains("HelloWorld"));
    }

    @Test
    void generate_ShouldHaveImageRelsAndMedia() throws Exception {
        // The preset images include sample.png; verify it ends up in the docx
        GenerateDocumentCommand command = new GenerateDocumentCommand("With Image", "Body");
        byte[] result = service.generate(command).getContent();

        byte[] mediaBytes = readZipEntry(result, "word/media/sample.png");
        assertNotNull(mediaBytes);
        assertTrue(mediaBytes.length > 0);

        byte[] relsBytes = readZipEntry(result, "word/_rels/document.xml.rels");
        String relsXml = new String(relsBytes, StandardCharsets.UTF_8);
        assertTrue(relsXml.contains("rIdImg1"));
        assertTrue(relsXml.contains("media/sample.png"));
    }

    @Test
    void generate_ShouldNotContainDrawingsWhenNoImages() throws Exception {
        // The preset images are always loaded; this test verifies they appear correctly.
        GenerateDocumentCommand command = new GenerateDocumentCommand("Title", "No images here");
        byte[] result = service.generate(command).getContent();
        byte[] docXmlBytes = readZipEntry(result, "word/document.xml");
        String docXml = new String(docXmlBytes, StandardCharsets.UTF_8);

        assertTrue(docXml.contains("w:drawing"),
                "Should contain drawing elements when preset images are present");
    }

    // ═══════════════════════════════════════════════════════════════
    // Test helpers
    // ═══════════════════════════════════════════════════════════════

    private String renderTemplate(String templateName, Object dataModel)
            throws Exception {
        return templateRenderer.renderTemplate(templateName, dataModel);
    }

    private boolean isValidZip(byte[] data) {
        return data.length > 22
                && data[0] == 0x50 && data[1] == 0x4B
                && data[2] == 0x03 && data[3] == 0x04;
    }

    private List<String> listZipEntries(byte[] zipBytes) throws IOException {
        List<String> names = new ArrayList<>();
        try (ZipInputStream zis = new ZipInputStream(
                new ByteArrayInputStream(zipBytes))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                names.add(entry.getName());
            }
        }
        return names;
    }

    private byte[] readZipEntry(byte[] zipBytes, String entryName)
            throws IOException {
        try (ZipInputStream zis = new ZipInputStream(
                new ByteArrayInputStream(zipBytes))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.getName().equals(entryName)) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = zis.read(buf)) != -1) {
                        bos.write(buf, 0, len);
                    }
                    return bos.toByteArray();
                }
            }
        }
        throw new IllegalArgumentException("Entry not found: " + entryName);
    }
}
