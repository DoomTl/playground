package com.example.worddoc.infrastructure.zip;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.*;

class ZipUtilTest {

    // ─── Helper: create minimal ZIP bytes ─────────────────────────

    static byte[] createZip(String... nameContentPairs) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            for (int i = 0; i < nameContentPairs.length; i += 2) {
                String name = nameContentPairs[i];
                String content = nameContentPairs[i + 1];
                zos.putNextEntry(new ZipEntry(name));
                zos.write(content.getBytes("UTF-8"));
                zos.closeEntry();
            }
        }
        return bos.toByteArray();
    }

    static byte[] createLargeZip(long entryDataSize) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            zos.putNextEntry(new ZipEntry("large.dat"));
            byte[] chunk = new byte[8192];
            long written = 0;
            while (written < entryDataSize) {
                int toWrite = (int) Math.min(chunk.length, entryDataSize - written);
                zos.write(chunk, 0, toWrite);
                written += toWrite;
            }
            zos.closeEntry();
        }
        return bos.toByteArray();
    }

    static byte[] readZipEntry(byte[] zipBytes, String entryName) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.getName().equals(entryName)) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = zis.read(buf)) != -1) {
                        bos.write(buf, 0, len);
                    }
                    return bos.toByteArray();
                }
            }
        }
        throw new IllegalArgumentException("Entry not found: " + entryName);
    }

    static int countZipEntries(byte[] zipBytes) throws IOException {
        int count = 0;
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            while (zis.getNextEntry() != null) {
                count++;
            }
        }
        return count;
    }

    // ═══════════════════════════════════════════════════════════════
    // Section 2: Safety Validations
    // ═══════════════════════════════════════════════════════════════

    // ─── 2.1 RED: Path traversal ─────────────────────────────────

    @Test
    void replaceEntry_ShouldRejectPathTraversal_ParentDir() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.replaceEntry(zip, "../../etc/passwd", "evil".getBytes()));
    }

    @Test
    void replaceEntry_ShouldRejectAbsolutePath() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.replaceEntry(zip, "/etc/passwd", "evil".getBytes()));
    }

    @Test
    void replaceEntry_ShouldRejectWindowsDrivePath() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.replaceEntry(zip, "C:\\Windows\\system32", "evil".getBytes()));
    }

    @Test
    void replaceEntry_ShouldRejectNullByteInjection() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.replaceEntry(zip, "safe.txt\0../../evil.txt", "evil".getBytes()));
    }

    @Test
    void validateEntryName_ShouldNormalizeAndRejectPathTraversal() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.replaceEntry(zip, "text/../../foo", "evil".getBytes()));
    }

    @Test
    void addEntry_ShouldRejectPathTraversal() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.addEntry(zip, "../../evil.txt", "evil".getBytes()));
    }

    @Test
    void addEntry_ShouldRejectAbsolutePath() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.addEntry(zip, "/etc/evil.txt", "evil".getBytes()));
    }

    @Test
    void addEntry_ShouldRejectNullByteInjection() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.addEntry(zip, "safe\0../../evil.txt", "evil".getBytes()));
    }

    // ─── 2.3 RED: Symlink detection ──────────────────────────────

    @Test
    void isUnixSymlink_ShouldReturnFalseForNormalEntry() {
        ZipEntry entry = new ZipEntry("normal.txt");
        assertFalse(ZipUtil.isUnixSymlink(entry));
    }

    @Test
    void isUnixSymlink_UsesReflectionOnJava12Plus() throws Exception {
        ZipEntry entry = new ZipEntry("normal.txt");
        assertFalse(ZipUtil.isUnixSymlink(entry));
    }

    // ─── 2.5 RED: ZIP bomb detection ─────────────────────────────

    @Test
    void shouldRejectHighCompressionRatio() throws IOException {
        byte[] zip = ZipUtilTestHelper.createHighCompressionRatioZip();
        assertThrows(SecurityException.class,
                () -> ZipUtil.readAllEntriesSafe(zip));
    }

    @Test
    void shouldRejectTooManyEntries() throws IOException {
        byte[] zip = ZipUtilTestHelper.createZipWithManyEntries(ZipUtil.MAX_ENTRY_COUNT + 1);
        assertThrows(SecurityException.class,
                () -> ZipUtil.readAllEntriesSafe(zip));
    }

    @Test
    void shouldRejectOversizedTotalContent() throws IOException {
        byte[] zip = createLargeZip((int) (ZipUtil.MAX_TOTAL_UNCOMPRESSED_SIZE + 1));
        assertThrows(SecurityException.class,
                () -> ZipUtil.readAllEntriesSafe(zip));
    }

    // ─── 2.7 RED: Duplicate case-insensitive name ────────────────

    @Test
    void shouldRejectCaseInsensitiveDuplicateName() throws IOException {
        byte[] zip = ZipUtilTestHelper.createZipWithDuplicateCase();
        assertThrows(SecurityException.class,
                () -> ZipUtil.readAllEntriesSafe(zip));
    }

    // ═══════════════════════════════════════════════════════════════
    // Section 3: Core Operations
    // ═══════════════════════════════════════════════════════════════

    // ─── 3.1 RED: replaceEntry replaces existing entry ───────────

    @Test
    void replaceEntry_ShouldReplaceExistingEntry() throws IOException {
        byte[] zip = createZip(
                "hello.txt", "original content",
                "world.txt", "world content");
        byte[] newZip = ZipUtil.replaceEntry(zip, "hello.txt", "modified content".getBytes());
        byte[] actual = readZipEntry(newZip, "hello.txt");
        assertEquals("modified content", new String(actual, "UTF-8"));
    }

    // ─── 3.3 RED: replaceEntry throws when not found ────────────

    @Test
    void replaceEntry_ShouldThrowWhenEntryNotFound() throws IOException {
        byte[] zip = createZip("hello.txt", "content");
        assertThrows(IllegalArgumentException.class,
                () -> ZipUtil.replaceEntry(zip, "nonexistent.txt", "data".getBytes()));
    }

    // ─── 3.5 RED: addEntry adds new entry ───────────────────────

    @Test
    void addEntry_ShouldAddNewEntry() throws IOException {
        byte[] zip = createZip("hello.txt", "hello");
        byte[] newZip = ZipUtil.addEntry(zip, "new.txt", "new content".getBytes());
        byte[] actual = readZipEntry(newZip, "new.txt");
        assertEquals("new content", new String(actual, "UTF-8"));
        assertEquals(2, countZipEntries(newZip));
    }

    // ─── 3.7 RED: addEntry throws when duplicate ────────────────

    @Test
    void addEntry_ShouldThrowWhenEntryExists() throws IOException {
        byte[] zip = createZip("hello.txt", "hello");
        assertThrows(IllegalArgumentException.class,
                () -> ZipUtil.addEntry(zip, "hello.txt", "duplicate".getBytes()));
    }

    // ─── Edge cases ─────────────────────────────────────────────

    @Test
    void replaceEntry_ShouldRejectEmptyEntryName() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(IllegalArgumentException.class,
                () -> ZipUtil.replaceEntry(zip, "", "data".getBytes()));
    }

    @Test
    void replaceEntry_ShouldRejectNullEntryName() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        assertThrows(IllegalArgumentException.class,
                () -> ZipUtil.replaceEntry(zip, null, "data".getBytes()));
    }

    @Test
    void addEntry_ShouldRejectEntryNameTooLong() {
        byte[] zip = ZipUtilTestHelper.createMinimalZip();
        char[] chars = new char[ZipUtil.MAX_ENTRY_NAME_LENGTH + 1];
        Arrays.fill(chars, 'a');
        String longName = new String(chars);
        assertThrows(SecurityException.class,
                () -> ZipUtil.addEntry(zip, longName, "data".getBytes()));
    }
}
