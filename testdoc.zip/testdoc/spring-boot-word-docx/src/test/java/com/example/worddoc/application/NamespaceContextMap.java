package com.example.worddoc.application;

import javax.xml.namespace.NamespaceContext;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class NamespaceContextMap implements NamespaceContext {

    private final Map<String, String> prefixToUri = new HashMap<>();
    private final Map<String, String> uriToPrefix = new HashMap<>();

    NamespaceContextMap(String... pairs) {
        for (int i = 0; i < pairs.length; i += 2) {
            String prefix = pairs[i];
            String uri = pairs[i + 1];
            prefixToUri.put(prefix, uri);
            uriToPrefix.put(uri, prefix);
        }
    }

    @Override
    public String getNamespaceURI(String prefix) {
        if (prefix == null) {
            throw new IllegalArgumentException("Prefix must not be null");
        }
        String uri = prefixToUri.get(prefix);
        return uri != null ? uri : "";
    }

    @Override
    public String getPrefix(String namespaceURI) {
        if (namespaceURI == null) {
            throw new IllegalArgumentException("Namespace URI must not be null");
        }
        String prefix = uriToPrefix.get(namespaceURI);
        return prefix != null ? prefix : "";
    }

    @Override
    public Iterator<String> getPrefixes(String namespaceURI) {
        return uriToPrefix.keySet().iterator();
    }
}
