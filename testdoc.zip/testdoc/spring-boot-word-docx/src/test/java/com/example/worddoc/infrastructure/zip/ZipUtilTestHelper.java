package com.example.worddoc.infrastructure.zip;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class ZipUtilTestHelper {

    private ZipUtilTestHelper() {
    }

    static byte[] createMinimalZip() {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (ZipOutputStream zos = new ZipOutputStream(bos)) {
                zos.putNextEntry(new ZipEntry("test.txt"));
                zos.write("hello".getBytes("UTF-8"));
                zos.closeEntry();
            }
            return bos.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    static byte[] createHighCompressionRatioZip() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            ZipEntry entry = new ZipEntry("bomb.txt");
            zos.putNextEntry(entry);
            byte[] zeros = new byte[1024 * 1024];
            zos.write(zeros);
            zos.closeEntry();
        }
        return bos.toByteArray();
    }

    static byte[] createZipWithManyEntries(int count) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            for (int i = 0; i < count; i++) {
                zos.putNextEntry(new ZipEntry("file_" + i + ".txt"));
                zos.write("x".getBytes("UTF-8"));
                zos.closeEntry();
            }
        }
        return bos.toByteArray();
    }

    static byte[] createZipWithDuplicateCase() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            zos.putNextEntry(new ZipEntry("Readme.txt"));
            zos.write("content1".getBytes("UTF-8"));
            zos.closeEntry();
            zos.putNextEntry(new ZipEntry("readme.txt"));
            zos.write("content2".getBytes("UTF-8"));
            zos.closeEntry();
        }
        return bos.toByteArray();
    }
}
