package com.example.worddoc.application.dto;

import com.example.worddoc.domain.model.DocumentData;
import com.example.worddoc.domain.model.PreSetImage;
import lombok.Value;

import java.util.List;

@Value
public class GenerateDocumentCommand {

    String title;
    String bodyText;

    public DocumentData toDomain(List<PreSetImage> images) {
        return new DocumentData(title, bodyText, images);
    }
}
