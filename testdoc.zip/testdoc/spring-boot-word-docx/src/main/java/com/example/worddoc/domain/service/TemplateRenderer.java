package com.example.worddoc.domain.service;

public interface TemplateRenderer {

    String renderTemplate(String templateName, Object model);
}
