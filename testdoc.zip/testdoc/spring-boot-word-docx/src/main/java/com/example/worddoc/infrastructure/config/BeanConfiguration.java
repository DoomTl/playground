package com.example.worddoc.infrastructure.config;

import com.example.worddoc.domain.service.ArchiveEditor;
import com.example.worddoc.domain.service.DocxAssembler;
import com.example.worddoc.domain.service.TemplateRenderer;
import com.example.worddoc.infrastructure.template.FreeMarkerTemplateRenderer;
import com.example.worddoc.infrastructure.zip.ZipArchiveEditor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

@Configuration
public class BeanConfiguration {

    @Bean
    public TemplateRenderer templateRenderer(FreeMarkerConfigurer freeMarkerConfigurer) {
        return new FreeMarkerTemplateRenderer(freeMarkerConfigurer);
    }

    @Bean
    public ArchiveEditor archiveEditor() {
        return new ZipArchiveEditor();
    }

    @Bean
    public DocxAssembler docxAssembler(TemplateRenderer templateRenderer, ArchiveEditor archiveEditor) {
        return new DocxAssembler(templateRenderer, archiveEditor);
    }
}
