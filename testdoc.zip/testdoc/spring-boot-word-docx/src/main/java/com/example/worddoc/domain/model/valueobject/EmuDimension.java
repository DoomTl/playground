package com.example.worddoc.domain.model.valueobject;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class EmuDimension {

    private final long value;

    public static EmuDimension of(long value) {
        if (value <= 0) {
            throw new IllegalArgumentException("Dimension must be positive: " + value);
        }
        return new EmuDimension(value);
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
