package com.example.worddoc.infrastructure.zip;

import com.example.worddoc.domain.service.ArchiveEditor;

public class ZipArchiveEditor implements ArchiveEditor {

    @Override
    public byte[] replace(byte[] archive, String entryName, byte[] content) {
        return ZipUtil.replaceEntry(archive, entryName, content);
    }

    @Override
    public byte[] add(byte[] archive, String entryName, byte[] content) {
        return ZipUtil.addEntry(archive, entryName, content);
    }
}
