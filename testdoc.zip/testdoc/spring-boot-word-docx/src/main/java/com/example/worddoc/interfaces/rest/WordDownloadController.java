package com.example.worddoc.interfaces.rest;

import com.example.worddoc.application.WordDocApplicationService;
import com.example.worddoc.application.dto.DocumentResult;
import com.example.worddoc.application.dto.GenerateDocumentCommand;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WordDownloadController {

    private final WordDocApplicationService wordDocApplicationService;

    public WordDownloadController(WordDocApplicationService wordDocApplicationService) {
        this.wordDocApplicationService = wordDocApplicationService;
    }

    @GetMapping("/download")
    public ResponseEntity<Resource> download(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String bodyText) {

        GenerateDocumentCommand command = new GenerateDocumentCommand(title, bodyText);
        DocumentResult result = wordDocApplicationService.generate(command);

        ByteArrayResource resource = new ByteArrayResource(result.getContent());
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=document.docx")
                .body(resource);
    }
}
