package com.example.worddoc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentData {

    private String title;
    private String bodyText;
    private List<PreSetImage> images;
}
