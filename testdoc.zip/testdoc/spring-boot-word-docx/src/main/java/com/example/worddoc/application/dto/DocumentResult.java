package com.example.worddoc.application.dto;

import lombok.Value;

@Value
public class DocumentResult {
    byte[] content;
}
