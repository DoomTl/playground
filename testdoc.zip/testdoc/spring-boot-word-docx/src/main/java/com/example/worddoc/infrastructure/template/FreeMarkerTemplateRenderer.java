package com.example.worddoc.infrastructure.template;

import com.example.worddoc.domain.service.TemplateRenderer;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import java.io.IOException;
import java.io.StringWriter;

public class FreeMarkerTemplateRenderer implements TemplateRenderer {

    private final freemarker.template.Configuration freemarkerConfig;

    public FreeMarkerTemplateRenderer(FreeMarkerConfigurer freeMarkerConfigurer) {
        this.freemarkerConfig = freeMarkerConfigurer.getConfiguration();
    }

    @Override
    public String renderTemplate(String templateName, Object model) {
        try {
            Template template = freemarkerConfig.getTemplate(templateName);
            StringWriter writer = new StringWriter();
            template.process(model, writer);
            return writer.toString();
        } catch (IOException | TemplateException e) {
            throw new RuntimeException("Failed to render template: " + templateName, e);
        }
    }
}
