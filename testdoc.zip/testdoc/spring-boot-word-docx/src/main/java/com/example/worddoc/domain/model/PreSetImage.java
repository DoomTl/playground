package com.example.worddoc.domain.model;

import com.example.worddoc.domain.model.valueobject.EmuDimension;
import com.example.worddoc.domain.model.valueobject.ImageFileName;
import lombok.Data;

@Data
public class PreSetImage {

    private ImageFileName fileName;
    private byte[] data;
    private EmuDimension widthEmu;
    private EmuDimension heightEmu;

    public PreSetImage(String fileName, byte[] data, long widthEmu, long heightEmu) {
        this.fileName = ImageFileName.of(fileName);
        this.data = data;
        this.widthEmu = EmuDimension.of(widthEmu);
        this.heightEmu = EmuDimension.of(heightEmu);
    }
}
