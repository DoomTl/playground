package com.example.worddoc.infrastructure.zip;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.Normalizer;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class ZipUtil {

    static final int MAX_ENTRY_COUNT = 10_000;
    static final int MAX_ENTRY_SIZE = 100 * 1024 * 1024;
    static final long MAX_TOTAL_UNCOMPRESSED_SIZE = 1024L * 1024 * 1024;
    static final int MAX_COMPRESSION_RATIO = 100;
    static final int MAX_ENTRY_NAME_LENGTH = 255;

    private ZipUtil() {
    }

    public static byte[] replaceEntry(byte[] zipBytes, String entryName, byte[] newContent) {
        validateEntryName(entryName);
        Map<String, byte[]> entries = readAllEntriesSafe(zipBytes);
        if (!entries.containsKey(entryName)) {
            throw new IllegalArgumentException("Entry not found in ZIP: " + entryName);
        }
        entries.put(entryName, newContent);
        try {
            return writeZip(entries);
        } catch (IOException e) {
            throw new RuntimeException("Failed to write ZIP", e);
        }
    }

    public static byte[] addEntry(byte[] zipBytes, String entryName, byte[] content) {
        validateEntryName(entryName);
        Map<String, byte[]> entries = readAllEntriesSafe(zipBytes);
        if (entries.containsKey(entryName)) {
            throw new IllegalArgumentException("Entry already exists in ZIP: " + entryName);
        }
        entries.put(entryName, content);
        try {
            return writeZip(entries);
        } catch (IOException e) {
            throw new RuntimeException("Failed to write ZIP", e);
        }
    }

    static Map<String, byte[]> readAllEntriesSafe(byte[] zipBytes) {
        try {
            Map<String, byte[]> entries = new LinkedHashMap<>();
            Set<String> seenNames = new HashSet<>();
            int entryCount = 0;
            long totalUncompressed = 0;

            try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    entryCount++;
                    if (entryCount > MAX_ENTRY_COUNT) {
                        throw new SecurityException("Too many ZIP entries: " + entryCount);
                    }

                    String name = entry.getName();
                    validateEntryName(name);

                    if (isUnixSymlink(entry)) {
                        throw new SecurityException("Symlink entry not allowed: " + name);
                    }

                    String lowerName = name.toLowerCase(Locale.ROOT);
                    if (!seenNames.add(lowerName)) {
                        throw new SecurityException("Duplicate entry name (case-insensitive): " + name);
                    }

                    if (entry.isDirectory()) {
                        entries.put(name, new byte[0]);
                        continue;
                    }

                    byte[] data = readEntryBytes(zis, entry);

                    if (data.length > MAX_ENTRY_SIZE) {
                        throw new SecurityException("Entry too large: " + name + " (" + data.length + " bytes)");
                    }

                    totalUncompressed += data.length;
                    if (totalUncompressed > MAX_TOTAL_UNCOMPRESSED_SIZE) {
                        throw new SecurityException("Total uncompressed size exceeded");
                    }

                    long compressedSize = entry.getCompressedSize();
                    if (compressedSize > 0) {
                        double ratio = (double) data.length / compressedSize;
                        if (ratio > MAX_COMPRESSION_RATIO) {
                            throw new SecurityException(
                                    "Compression ratio too high: " + String.format("%.1f", ratio) + ":1 for entry: " + name);
                        }
                    }

                    entries.put(name, data);
                }
            }

            return entries;
        } catch (SecurityException | IllegalArgumentException e) {
            throw e;
        } catch (IOException e) {
            throw new RuntimeException("Failed to read ZIP entries", e);
        }
    }

    static byte[] readEntryBytes(ZipInputStream zis, ZipEntry entry) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int len;
        while ((len = zis.read(buffer)) != -1) {
            bos.write(buffer, 0, len);
        }
        return bos.toByteArray();
    }

    static byte[] writeZip(Map<String, byte[]> entries) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            for (Map.Entry<String, byte[]> e : entries.entrySet()) {
                ZipEntry zipEntry = new ZipEntry(e.getKey());
                byte[] data = e.getValue();
                zipEntry.setSize(data.length);
                zos.putNextEntry(zipEntry);
                zos.write(data);
                zos.closeEntry();
            }
        }
        return bos.toByteArray();
    }

    static boolean isUnixSymlink(ZipEntry entry) {
        try {
            java.lang.reflect.Method method = ZipEntry.class.getMethod("isUnixSymlink");
            return (boolean) method.invoke(entry);
        } catch (NoSuchMethodException e) {
            return checkSymlinkViaExtraField(entry);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean checkSymlinkViaExtraField(ZipEntry entry) {
        byte[] extra = entry.getExtra();
        if (extra == null || extra.length < 4) return false;
        int i = 0;
        while (i + 3 < extra.length) {
            int tag = (extra[i] & 0xFF) | ((extra[i + 1] & 0xFF) << 8);
            int size = (extra[i + 2] & 0xFF) | ((extra[i + 3] & 0xFF) << 8);
            if (i + 4 + size > extra.length) break;
            if (tag == 0x5855 && size >= 5) {
                int mode = 0;
                for (int j = 0; j < 4 && (i + 4 + j) < extra.length; j++) {
                    mode |= (extra[i + 4 + j] & 0xFF) << (j * 8);
                }
                return (mode & 0120000) == 0120000;
            }
            i += 4 + size;
        }
        return false;
    }

    static void validateEntryName(String entryName) {
        if (entryName == null || entryName.trim().isEmpty()) {
            throw new IllegalArgumentException("Entry name must not be null or empty");
        }

        if (entryName.contains("\0")) {
            throw new SecurityException("Null byte in entry name: " + entryName);
        }

        String normalized = Normalizer.normalize(entryName, Normalizer.Form.NFC)
                .replace('\\', '/');

        if (normalized.length() > MAX_ENTRY_NAME_LENGTH) {
            throw new SecurityException("Entry name too long: " + normalized.length() + " chars");
        }

        if (normalized.contains("..")) {
            throw new SecurityException("Path traversal detected: " + entryName);
        }

        if (normalized.startsWith("/")) {
            throw new SecurityException("Absolute path not allowed: " + entryName);
        }

        if (normalized.matches("^[a-zA-Z]:/.*")) {
            throw new SecurityException("Drive letter path not allowed: " + entryName);
        }
    }
}
