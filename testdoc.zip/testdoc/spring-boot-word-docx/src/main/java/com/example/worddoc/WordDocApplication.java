package com.example.worddoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordDocApplication {

    public static void main(String[] args) {
        SpringApplication.run(WordDocApplication.class, args);
    }
}
