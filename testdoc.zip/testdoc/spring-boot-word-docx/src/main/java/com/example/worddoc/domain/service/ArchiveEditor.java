package com.example.worddoc.domain.service;

public interface ArchiveEditor {

    byte[] replace(byte[] archive, String entryName, byte[] content);

    byte[] add(byte[] archive, String entryName, byte[] content);
}
