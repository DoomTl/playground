package com.example.worddoc.application;

import com.example.worddoc.application.dto.DocumentResult;
import com.example.worddoc.application.dto.GenerateDocumentCommand;
import com.example.worddoc.domain.model.DocumentData;
import com.example.worddoc.domain.model.PreSetImage;
import com.example.worddoc.domain.service.DocxAssembler;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class WordDocApplicationService {

    private final DocxAssembler docxAssembler;

    public WordDocApplicationService(DocxAssembler docxAssembler) {
        this.docxAssembler = docxAssembler;
    }

    public DocumentResult generate(GenerateDocumentCommand command) {
        List<PreSetImage> images = loadPreSetImages();
        DocumentData data = command.toDomain(images);
        byte[] templateDocx = loadTemplateDocx();
        byte[] result = docxAssembler.assemble(data, templateDocx);
        return new DocumentResult(result);
    }

    private List<PreSetImage> loadPreSetImages() {
        List<PreSetImage> images = new ArrayList<>();
        String[] imageNames = {"sample.png"};
        for (String name : imageNames) {
            try (InputStream is = getClass().getClassLoader()
                    .getResourceAsStream("images/" + name)) {
                if (is != null) {
                    byte[] data = readAllBytes(is);
                    images.add(new PreSetImage(name, data, 914400L, 914400L));
                }
            } catch (IOException ignored) {
            }
        }
        return images;
    }

    private byte[] loadTemplateDocx() {
        try (InputStream is = getClass().getClassLoader()
                .getResourceAsStream("template.docx")) {
            if (is == null) {
                throw new IOException("template.docx not found in classpath");
            }
            return readAllBytes(is);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load template.docx", e);
        }
    }

    private byte[] readAllBytes(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int len;
        while ((len = is.read(buf)) != -1) {
            bos.write(buf, 0, len);
        }
        return bos.toByteArray();
    }
}
