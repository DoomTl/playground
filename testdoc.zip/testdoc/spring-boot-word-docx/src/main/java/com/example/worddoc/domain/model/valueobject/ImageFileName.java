package com.example.worddoc.domain.model.valueobject;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class ImageFileName {

    private final String value;

    public static ImageFileName of(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("Image file name must not be null or empty");
        }
        if (value.contains("/") || value.contains("\\") || value.contains("..")) {
            throw new IllegalArgumentException("Invalid image file name: " + value);
        }
        if (value.length() > 255) {
            throw new IllegalArgumentException("Image file name too long: " + value.length());
        }
        return new ImageFileName(value);
    }

    @Override
    public String toString() {
        return value;
    }
}
