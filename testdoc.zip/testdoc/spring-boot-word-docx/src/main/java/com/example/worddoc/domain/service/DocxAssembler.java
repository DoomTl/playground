package com.example.worddoc.domain.service;

import com.example.worddoc.domain.model.DocumentData;
import com.example.worddoc.domain.model.PreSetImage;

import java.nio.charset.StandardCharsets;

public class DocxAssembler {

    private final TemplateRenderer templateRenderer;
    private final ArchiveEditor archiveEditor;

    public DocxAssembler(TemplateRenderer templateRenderer, ArchiveEditor archiveEditor) {
        this.templateRenderer = templateRenderer;
        this.archiveEditor = archiveEditor;
    }

    public byte[] assemble(DocumentData data, byte[] templateDocx) {
        String documentXml = templateRenderer.renderTemplate("document.xml.ftl", data);
        templateDocx = archiveEditor.replace(
                templateDocx,
                "word/document.xml",
                documentXml.getBytes(StandardCharsets.UTF_8));

        String relsXml = templateRenderer.renderTemplate("document.xml.rels.ftl", data);
        templateDocx = archiveEditor.replace(
                templateDocx,
                "word/_rels/document.xml.rels",
                relsXml.getBytes(StandardCharsets.UTF_8));

        if (data.getImages() != null) {
            for (PreSetImage img : data.getImages()) {
                templateDocx = archiveEditor.add(
                        templateDocx,
                        "word/media/" + img.getFileName(),
                        img.getData());
            }
        }

        return templateDocx;
    }
}
